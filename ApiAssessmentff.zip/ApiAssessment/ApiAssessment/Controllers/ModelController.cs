﻿using ApiAssessment.Data;
using ApiAssessment.ModelLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ApiAssessment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ModelController : ControllerBase
    {
        private readonly ApiDbContext _context;

        public ModelController(ApiDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetModelsByBrand(int? brandId)
        {
            try
            {
                var exist = _context.Brands.Any(b => b.BrandId == brandId);
                if (exist)
                {
                    var model =  await _context.Models.Where(m => m.BrandId == brandId).ToListAsync();
                    return Ok(model);
                }
                return NotFound("model not found");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddModel(Models model)
        {
            try
            {
                var exist = _context.Brands.Any(b => b.BrandId == model.BrandId);
                if (exist)
                {
                    _context.Models.Add(model);
                    await _context.SaveChangesAsync();
                    return Ok(model);
                }
                return NotFound("Brand id doesnt exist");
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
    }
}
