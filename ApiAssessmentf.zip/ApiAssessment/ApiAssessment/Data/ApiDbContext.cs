﻿using ApiAssessment.ModelLayer;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace ApiAssessment.Data
{
    public class ApiDbContext : DbContext
    {
        public ApiDbContext(DbContextOptions<ApiDbContext> options) : base(options)
        {

        }

        public DbSet<Brands> Brands { get; set; }
        public DbSet<VehicleTypes> VehicleTypes { get; set; }
        public DbSet<Models> Models { get; set; }

        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            //Primary Key For Brands
            modelBuilder.Entity<VehicleTypes>().HasKey(vehicleType => vehicleType.VehicleTypeId);
            //Relation between Vehicle Type & Brands
            modelBuilder.Entity<VehicleTypes>()
                        .HasMany(vehicleType => vehicleType.Brands)
                        .WithOne(brand => brand.VehicleType)
                        .HasForeignKey(brand => brand.VehicleTypeId);


            //Primary Key For Brands
            modelBuilder.Entity<Brands>().HasKey(brands => brands.BrandId);
            //Relation between Brands & Vehicle Brands
            modelBuilder.Entity<Brands>()
                        .HasOne(brand => brand.VehicleType)
                        .WithMany(vehicleType => vehicleType.Brands)
                        .HasForeignKey(brand => brand.VehicleTypeId);


            //Primary Key For Model
            modelBuilder.Entity<Models>().HasKey(model => model.ModelId);
            //Relation between Model & Brands
            modelBuilder.Entity<Models>()
                .HasOne(model => model.Brands)
                .WithMany(brands => brands.Model)
                .HasForeignKey(model => model.BrandId); 

        } 


    }
}
    /*
    public class YourDbContextFactory : IDesignTimeDbContextFactory<ApiDbContext>
    {
        public ApiDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<ApiDbContext>();
            optionsBuilder.UseSqlServer("ApiConnectionString");

            return new ApiDbContext(optionsBuilder.Options);
        }
    } */

