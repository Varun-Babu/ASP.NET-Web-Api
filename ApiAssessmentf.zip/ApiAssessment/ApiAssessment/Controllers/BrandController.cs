﻿using ApiAssessment.Data;
using ApiAssessment.ModelLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ApiAssessment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BrandController : ControllerBase
    {
        private readonly ApiDbContext _context;

        public BrandController(ApiDbContext context)
        {
            _context = context;
        }

        [HttpGet]

        public async Task<ActionResult> GetBrands(int? vehicleTypeId)
        {
            try
            {
                var exist = _context.Models.Any(b => b.ModelId == vehicleTypeId);
                if (exist)
                {
                    var brand = await _context.Brands.Where(b => b.VehicleTypeId == vehicleTypeId).ToListAsync();
                    return Ok(brand);
                }
                return NotFound("Brand Not Found");
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message); 
            }
        }


        [HttpPost]
        public async Task<ActionResult<Brands>> PostBrand(Brands brand)
        {
            _context.Brands.Add(brand);
            await _context.SaveChangesAsync();
            return Ok(brand);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBrand(int id)
        {
            try
            {
                var brand = await _context.Brands.FindAsync(id);
                if (brand == null)
                {
                    return NotFound();
                }
                _context.Brands.Remove(brand);
                await _context.SaveChangesAsync();
                return Ok("deleted");
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
           
        }
    }
}
