﻿using ApiAssessment.Data;
using ApiAssessment.ModelLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ApiAssessment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleTypeController : ControllerBase
    {
        private readonly ApiDbContext _context;
        public VehicleTypeController(ApiDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllVehicleType()
        {
           
             var vehicleType = await _context.VehicleTypes.ToListAsync();
             return Ok(vehicleType);
        }

        [HttpGet]
        [Route("{id:int}")]
        public async Task<IActionResult> GetVehicleById([FromRoute] int id)
        {
            try
            {
                var vehicleType = await _context.VehicleTypes.FirstOrDefaultAsync(x => x.VehicleTypeId == id);
                if(vehicleType != null)
                {
                    return Ok(vehicleType);
                }
                else
                {
                    return NotFound("vehicle type not found");
                }  
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        [HttpPost]
        public async Task<IActionResult> AddVehicleType([FromBody] VehicleTypes vehicleType)
        {
            await _context.VehicleTypes.AddAsync(vehicleType);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetVehicleById), new { id = vehicleType.VehicleTypeId }, vehicleType);
        }

        [HttpPut]
        [Route("{id:int}")]
        public async Task<IActionResult> UpdateVehicleType([FromRoute] int id, [FromBody] VehicleTypes vehicletype)
        {
            var existingVehicle = await _context.VehicleTypes.FirstOrDefaultAsync(x => x.VehicleTypeId == id);
            if (existingVehicle != null)
            {
                existingVehicle.VehicleType = vehicletype.VehicleType;
                existingVehicle.Description = vehicletype.Description;
                existingVehicle.IsActive = vehicletype.IsActive;
                await _context.SaveChangesAsync();
                return Ok(existingVehicle);
            }
            return NotFound("no such vehicle type exist");
        }
    }

}

